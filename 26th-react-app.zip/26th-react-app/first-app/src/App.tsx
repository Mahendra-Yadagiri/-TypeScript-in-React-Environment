import React from 'react';
import './App.css';
import Movie from './components/Movie';

function App() {
  return (
    <div className="App">
      <h1>Best Cars in the World — 2025 Picks</h1>
      <div className='adjust'>
      <Movie name="🚗 Kia EV3" director="Karim Habib"
      imgURL="./images/KIA-EV3-.jpg"
      description="Winner of the 2025 World Car of the Year — known for innovation, efficiency, and style."
      extraInfo="Engine: Electric — EV3 Gen-II" speed={180 }
       />
      </div>

      <div className='adjust'>
      <Movie name="🏎️ BMW M5" director="Michael Mauer"
      imgURL= "./images/bmw.jpg"
      description="A benchmark for performance sedans combining power, luxury, and usability."
      extraInfo="Engine: 4.4L Twin-Turbo V8" speed={305}
       />
      </div>

      <div className='adjust'>
      <Movie name="🚙 Porsche Macan" director="Davide Virdis"
      imgURL= "./images/porsche-macan.jpg"
      description="Luxury compact SUV with strong driving dynamics and elegant interior."
      extraInfo="Engine: 2.9L V6 Twin-Turbo" speed={260} />
    </div>
    </div>
  );
}

export default App;
