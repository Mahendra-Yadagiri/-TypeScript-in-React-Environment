import React from 'react'

interface movietitle{
    name:string,
    director:string,
    description: string;
  extraInfo: string;
    imgURL:string;
    speed:number
   
    
}
function Movie(props:movietitle) {
  return (
    <div>
      
      <div >
      <h3>{props.name}</h3>
      <h3>Designer_Name: {props.director}</h3>
      <img src={props.imgURL} alt=""></img>
      <p>{props.description}</p>
      <p>{props.extraInfo}</p>
      <h3>Top Speed:{props.speed}km/h</h3>
 
      </div>
      
    </div>
  )
}

export default Movie
